package com.example.test.serviceImpl;

import com.example.test.bean.Ergwc;
import com.example.test.mapper.ErgwcMapper;
import com.example.test.service.ErgwcService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ErgwcServiceImpl implements ErgwcService {

    @Autowired
    ErgwcMapper ergwcMapper;

    @Override
    public List<Ergwc> selectlBysearch(String sear) {
        return ergwcMapper.selectlBysearch(sear);
    }

    @Override
    public List<Ergwc> selectlBysearch1(String sear) {
        return ergwcMapper.selectlBysearch1(sear);
    }


    @Override
    public int insert(Ergwc record) {
        int aFlag = ergwcMapper.insert(record);
        return aFlag;
    }

    @Override
    public int deleteByPrimaryKey(String id) {
        int aFlag = ergwcMapper.deleteByPrimaryKey(id);
        return aFlag;
    }

    @Override
    public Ergwc selectByPrimaryKey(String id) {
        return ergwcMapper.selectByPrimaryKey(id);
    }

    @Override
    public int updateByPrimaryKey(Ergwc record) {
        int aFlag = ergwcMapper.updateByPrimaryKeySelective(record);
        return aFlag;
    }


}