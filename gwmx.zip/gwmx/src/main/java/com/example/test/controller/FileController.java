package com.example.test.controller;

import org.apache.commons.io.FileUtils;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.apache.tomcat.util.http.fileupload.util.Streams;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.UUID;

//上传不要用@Controller,用@RestController
@RestController
@RequestMapping("/file")
public class FileController {
    String imageFilePath = "D://project//gwmx//src//main//resources//static//upload//";

    @RequestMapping("/qdupload")
    //名字upload是固定的，有兴趣，可以打开浏览器查看元素验证
//    public Object uploadFile(@RequestParam("file") MultipartFile[] multipartFiles, final HttpServletResponse response, final HttpServletRequest request) {
    public String picurl(@RequestParam("file") MultipartFile file) throws Exception {
        // 获取文件名
        String fileName = file.getOriginalFilename();
        // 获取文件的后缀名
        String suffixName = fileName.substring(fileName.lastIndexOf("."));
        String imgid = UUID.randomUUID().toString().trim().replaceAll("-", "");
        //实际处理肯定是要加上一段唯一的字符串（如现在时间），这里简单加 cun
        String newFileName = imgid + suffixName;
        //使用架包 common-io实现图片上传
        FileUtils.copyInputStreamToFile(file.getInputStream(), new File(imageFilePath + newFileName));
        //实现图片回显，基本上是固定代码，只需改路劲即可
        String picurl = "http://localhost:23112/upload/"+imgid+suffixName;
//        StringBuffer sb = new StringBuffer();
//        sb.append("<script type=\"text/javascript\">");
//        sb.append("window.parent.CKEDITOR.tools.callFunction(1,'" + "http://localhost:8081/1.png"
//                + "','')");
//        sb.append("</script>");
        JSONObject json = new JSONObject();
        json.put("code", 200);
        json.put("face", picurl);
        System.out.println(json.toString());
        return json.toString();
//        return picurl;
    }


    private static final Logger logger = LoggerFactory.getLogger(FileController.class);
    //在文件操作中，不用/或者\最好，推荐使用File.separator
    private final static String fileDir = "files";
    private final static String rootPath = System.getProperty("user.home") + File.separator + fileDir + File.separator;

    @RequestMapping("/upload")
    public Object uploadFile(@RequestParam("file") MultipartFile[] multipartFiles, final HttpServletResponse response, final HttpServletRequest request) {
        File fileDir = new File(rootPath);
        if (!fileDir.exists() && !fileDir.isDirectory()) {
            fileDir.mkdirs();
        }
        try {
            if (multipartFiles != null && multipartFiles.length > 0) {
                for (int i = 0; i < multipartFiles.length; i++) {
                    try {
                        //以原来的名称命名,覆盖掉旧的
                        String storagePath = rootPath + multipartFiles[i].getOriginalFilename();
                        logger.info("上传的文件：" + multipartFiles[i].getName() + "," + multipartFiles[i].getContentType() + "," + multipartFiles[i].getOriginalFilename()
                                + "，保存的路径为：" + storagePath);
                        Streams.copy(multipartFiles[i].getInputStream(), new FileOutputStream(storagePath), true);
                        //或者下面的
                        // Path path = Paths.get(storagePath);
                        //Files.write(path,multipartFiles[i].getBytes());
                    } catch (IOException e) {
                        logger.error(String.valueOf(e));
                    }
                }
            }

        } catch (Exception e) {
            return e.getMessage();
        }
        return "上传成功!";
    }

    /**
     * http://localhost:8080/file/download?fileName=新建文本文档.txt
     *
     * @param fileName
     * @param response
     * @param request
     * @return
     */
    @RequestMapping("/download")
    public Object downloadFile(@RequestParam String fileName, final HttpServletResponse response, final HttpServletRequest request) {
        OutputStream os = null;
        InputStream is = null;
        try {
            // 取得输出流
            os = response.getOutputStream();
            // 清空输出流
            response.reset();
            response.setContentType("application/x-download;charset=GBK");
            response.setHeader("Content-Disposition", "attachment;filename=" + new String(fileName.getBytes("utf-8"), "iso-8859-1"));
            //读取流
            File f = new File(rootPath + fileName);
            is = new FileInputStream(f);
            if (is == null) {
                logger.error("下载附件失败，请检查文件“" + fileName + "”是否存在");
                return "下载附件失败，请检查文件“" + fileName + "”是否存在";
            }
            //复制
            IOUtils.copy(is, response.getOutputStream());
            response.getOutputStream().flush();
        } catch (IOException e) {
            return "下载附件失败,error:" + e.getMessage();
        }
        //文件的关闭放在finally中
        finally {
            try {
                if (is != null) {
                    is.close();
                }
            } catch (IOException e) {
                logger.error(String.valueOf(e));
            }
            try {
                if (os != null) {
                    os.close();
                }
            } catch (IOException e) {
                logger.error(String.valueOf(e));
            }
        }
        return null;
    }
}
