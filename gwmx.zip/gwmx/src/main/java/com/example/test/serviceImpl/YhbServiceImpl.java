package com.example.test.serviceImpl;

import com.example.test.bean.Yhb;
import com.example.test.mapper.YhbMapper;
import com.example.test.service.YhbService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class YhbServiceImpl implements YhbService {

    @Autowired
    YhbMapper yhbMapper;

    @Override
    public List<Yhb> selectlByaccount(String account) {
        return yhbMapper.selectlByaccount(account);
    }

    @Override
    public Yhb selectllogin(String account, String password) {
        {
            return yhbMapper.selectllogin(account, password);
        }
    }

    @Override
    public List<Yhb> selectlBysearch(String sear) {
        return yhbMapper.selectlBysearch(sear);
    }


    @Override
    public int insert(Yhb record) {
        int aFlag = yhbMapper.insert(record);
        return aFlag;
    }

    @Override
    public int deleteByPrimaryKey(String id) {
        int aFlag = yhbMapper.deleteByPrimaryKey(id);
        return aFlag;
    }

    @Override
    public Yhb selectByPrimaryKey(String id) {
        return yhbMapper.selectByPrimaryKey(id);
    }

    @Override
    public int updateByPrimaryKey(Yhb record) {
        int aFlag = yhbMapper.updateByPrimaryKeySelective(record);
        return aFlag;
    }


}