package com.example.test.service;

import com.example.test.bean.Ergwc;

import java.util.List;

public interface ErgwcService {


    List<Ergwc> selectlBysearch(String sear);

    List<Ergwc> selectlBysearch1(String sear);

    int insert(Ergwc record);

    int deleteByPrimaryKey(String id);

    Ergwc selectByPrimaryKey(String id);

    int updateByPrimaryKey(Ergwc record);

}
