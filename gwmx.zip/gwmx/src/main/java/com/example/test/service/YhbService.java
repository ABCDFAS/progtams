package com.example.test.service;

import com.example.test.bean.Yhb;

import java.util.List;

public interface YhbService {

    List<Yhb> selectlByaccount(String account);
    Yhb selectllogin(String account, String password);

    List<Yhb> selectlBysearch(String sear);

    int insert(Yhb record);

    int deleteByPrimaryKey(String id);

    Yhb selectByPrimaryKey(String id);

    int updateByPrimaryKey(Yhb record);

}
