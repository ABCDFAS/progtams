package com.example.test.serviceImpl;

import com.example.test.bean.Ergm;
import com.example.test.mapper.ErgmMapper;
import com.example.test.service.ErgmService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ErgmServiceImpl implements ErgmService {

    @Autowired
    ErgmMapper ergmMapper;

    @Override
    public List<Ergm> selectlBysearch(String sear) {
        return ergmMapper.selectlBysearch(sear);
    }

    @Override
    public List<Ergm> selectlBysearch22(String ry5,String spmc) {
        return ergmMapper.selectlBysearch22( ry5, spmc);
    }


    @Override
    public List<Ergm> selectlBysearch1(String sear) {
        return ergmMapper.selectlBysearch1(sear);
    }

    @Override
    public List<Ergm> selectlBysearch2() {
        return ergmMapper.selectlBysearch2();
    }

    @Override
    public List<Ergm> selectlBysearch3() {
        return ergmMapper.selectlBysearch3();
    }


    @Override
    public List<Ergm> selectlBysearch4() {
        return ergmMapper.selectlBysearch4();
    }


    @Override
    public int insert(Ergm record) {
        int aFlag = ergmMapper.insert(record);
        return aFlag;
    }

    @Override
    public int deleteByPrimaryKey(String id) {
        int aFlag = ergmMapper.deleteByPrimaryKey(id);
        return aFlag;
    }

    @Override
    public Ergm selectByPrimaryKey(String id) {
        return ergmMapper.selectByPrimaryKey(id);
    }

    @Override
    public int updateByPrimaryKey(Ergm record) {
        int aFlag = ergmMapper.updateByPrimaryKeySelective(record);
        return aFlag;
    }


}