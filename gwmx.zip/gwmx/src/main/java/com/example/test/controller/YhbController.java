package com.example.test.controller;



import com.example.test.bean.Yhb;
import com.example.test.service.YhbService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@Controller
public class YhbController {


    @Autowired
    YhbService yhbService;

    //登录页面显示
    @RequestMapping("/login")
    public String loginshow() {
        return "login";
    }

    //主页页面显示
    @RequestMapping("/index")
    public String indexshow(ModelMap modelMap, @RequestParam(value = "account", required = false) String account) {
        return "index";
    }

    //个人资料显示
    @RequestMapping("/bascinfo")
    public String bascinfoshow() {
        return "html/bascinfo";
    }

    //注册
    @RequestMapping("/regMoth")
    @ResponseBody
    public Map regMoth(Yhb yhb) throws Exception {
        int flag = 0;
        String id = UUID.randomUUID().toString().trim().replaceAll("-", "");
        List<Yhb> list = yhbService.selectlByaccount(yhb.getAccount());
        if (list.size() > 0) {
            flag = 3;
        } else {
            //新增人
            yhb.setUserid(id);
            flag = yhbService.insert(yhb);
        }
        Map<String, Object> map = new HashMap<String, Object>();
        if (flag == 1) {
            map.put("code", "success");
            map.put("userid", id);
            return map;
        } else if (flag == 3) {
            map.put("code", "iscz");
            return map;
        } else {
            map.put("code", "error");
            return map;
        }
    }

    //登录验证
    @RequestMapping(value = "/loginMoth")
    @ResponseBody
    public Map loginMeth(Yhb yhb) {
        Map<String, Object> map = new HashMap<>();
        Yhb yhb1 = yhbService.selectllogin(yhb.getAccount(), yhb.getPassword());
        if (yhb1 != null) {
            map.put("userid", yhb1.getUserid());
            map.put("name", yhb1.getName());
            map.put("account", yhb1.getAccount());
            map.put("password", yhb1.getPassword());
            map.put("phone", yhb1.getPhone());
            map.put("address", yhb1.getAddress());
            map.put("roles", yhb1.getRoles());
            map.put("code", "0");
        } else {
            map.put("code", "1");
        }

        return map;

    }

    //人员列表弹窗
    @RequestMapping(value = "/yhblist", method = RequestMethod.GET)
    public String yhblist(ModelMap modelMap,
                          @RequestParam(value = "sear", required = false) String sear) {
        List<Yhb> list = yhbService.selectlBysearch(sear);
        modelMap.addAttribute("datas", list);
        return "html/yhblist";
    }

    //人新增弹窗
    @RequestMapping("/yhbadd")
    public String yhbaddshow(ModelMap modelMap) {
        List<Yhb> list = yhbService.selectlBysearch("");
        modelMap.addAttribute("datas", list);
        return "html/yhbadd";
    }


    /**
     * 新增人
     * remark：这里未做用户名是否重复校验
     */
    @RequestMapping("/addyhb")
    @ResponseBody
    public Map addyhb(Yhb yhb) {
        Date date = new Date();
        yhb.setUserid(UUID.randomUUID().toString().trim().replaceAll("-", ""));
        int flag = yhbService.insert(yhb);
        Map<String, Object> map = new HashMap<String, Object>();
        if (flag == 1) {
            map.put("code", "success");
            return map;
        } else {
            map.put("code", "error");
            return map;
        }
    }

    /**
     * 删除人
     */
    @RequestMapping(value = "/deleteyhb+{id}")
    public String deleteyhb(@PathVariable("id") String id, ModelMap modelMap) {
        int flag = yhbService.deleteByPrimaryKey(id);
        List<Yhb> list = yhbService.selectlBysearch("");
        modelMap.addAttribute("datas", list);
        return "html/yhblist";
    }

    //人修改弹窗
    @RequestMapping(value = "yhbedit", method = RequestMethod.GET)
    public String yhbedit(
            @RequestParam(name = "id", required = true) String id, ModelMap modelMap) {
        Yhb bean = yhbService.selectByPrimaryKey(id);
        modelMap.addAttribute("datas", bean);

        List<Yhb> list = yhbService.selectlBysearch("");
        modelMap.addAttribute("datasrole", list);
        return "html/yhbedit";
    }

    /**
     * 修改人
     */
    @RequestMapping("/updateyhb")
    @ResponseBody
    public Map updateyhb(Yhb yhb) {
        int flag = yhbService.updateByPrimaryKey(yhb);
        Map<String, Object> map = new HashMap<String, Object>();
        if (flag == 1) {
            map.put("code", "success");
            return map;
        } else {
            map.put("code", "error");
            return map;
        }
    }

    // 查询
    @RequestMapping("/yhblist")
    @ResponseBody
    public Map yhblist(Yhb yhb) {
        int flag = 0;
        List<Yhb> list = yhbService.selectlBysearch(yhb.getName());
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("list", list);
        return map;
    }

    //删除信息
    @RequestMapping("/deleteyhb")
    @ResponseBody
    public Map deleteyhb(Yhb yhb) {
        int flag = yhbService.deleteByPrimaryKey(yhb.getUserid());
        Map<String, Object> map = new HashMap<String, Object>();
        if (flag > 0) {
            map.put("code", "success");
        } else {
            map.put("code", "error");
        }
        return map;
    }


}
