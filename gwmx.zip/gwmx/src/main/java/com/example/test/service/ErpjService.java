package com.example.test.service;

import com.example.test.bean.Erpj;

import java.util.List;

public interface ErpjService {


    List<Erpj> selectlBysearch(String sear);

    List<Erpj> selectlBysearch1(String spid);


    int insert(Erpj record);

    int deleteByPrimaryKey(String id);

    Erpj selectByPrimaryKey(String id);

    int updateByPrimaryKey(Erpj record);

}
