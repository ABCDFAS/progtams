package com.example.test.controller;



import com.example.test.bean.Ersp;
import com.example.test.service.ErspService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.text.SimpleDateFormat;
import java.util.*;

@Controller
public class ErspController {


    @Autowired
    ErspService erspService;



    /**
     * 新增
     */
    @RequestMapping("/addersp")
    @ResponseBody
    public Map addersp(Ersp ersp) {
        Date date = new Date();
        ersp.setId(UUID.randomUUID().toString().trim().replaceAll("-", ""));
        String nowtime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()).toString();
        ersp.setRy6(nowtime);
        int flag = erspService.insert(ersp);
        Map<String, Object> map = new HashMap<String, Object>();
        if (flag == 1) {
            map.put("code", "success");
            return map;
        } else {
            map.put("code", "error");
            return map;
        }
    }


    /**
     * 修改
     */
    @RequestMapping("/updateersp")
    @ResponseBody
    public Map updateersp(Ersp ersp) {
        int flag = erspService.updateByPrimaryKey(ersp);
        Map<String, Object> map = new HashMap<String, Object>();
        if (flag == 1) {
            map.put("code", "success");
            return map;
        } else {
            map.put("code", "error");
            return map;
        }
    }

    //删除
    @RequestMapping("/deleteersp")
    @ResponseBody
    public Map deleteersp(Ersp ersp) {
        int flag = erspService.deleteByPrimaryKey(ersp.getId());
        Map<String, Object> map = new HashMap<String, Object>();
        if (flag > 0) {
            map.put("code", "success");
        } else {
            map.put("code", "error");
        }
        return map;
    }

    // 清单
    @RequestMapping("/ersplist")
    @ResponseBody
    public Map ersplist(Ersp ersp) {
        int flag = 0;
        List<Ersp> list = erspService.selectlBysearch(ersp.getMc());
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("list", list);
        return map;
    }


    // 清单
    @RequestMapping("/ersp_yhlist")
    @ResponseBody
    public Map ersp_yhlist(Ersp ersp) {
        int flag = 0;
        List<Ersp> list = erspService.selectlBysearch1(ersp.getRy10(),ersp.getMc());
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("list", list);
        return map;
    }

}
