package com.example.test.service;

import com.example.test.bean.Ergm;

import java.util.List;

public interface ErgmService {


    List<Ergm> selectlBysearch(String sear);

    List<Ergm> selectlBysearch22(String ry5,String spmc);
    List<Ergm> selectlBysearch1(String sear);

    List<Ergm> selectlBysearch2();
    List<Ergm> selectlBysearch3();
    List<Ergm> selectlBysearch4();

    int insert(Ergm record);

    int deleteByPrimaryKey(String id);

    Ergm selectByPrimaryKey(String id);

    int updateByPrimaryKey(Ergm record);

}
