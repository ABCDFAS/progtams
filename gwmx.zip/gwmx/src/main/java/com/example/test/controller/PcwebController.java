package com.example.test.controller;

import com.example.test.bean.*;
import com.example.test.service.ErgmService;
import com.example.test.service.ErgwcService;
import com.example.test.service.ErpjService;
import com.example.test.service.ErspService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class PcwebController {

    @Autowired
    ErgmService ergmService;


    @Autowired
    ErspService erspService;

    @Autowired
    ErpjService erpjService;

    @Autowired
    ErgwcService ergwcService;


    // 最新清单
    @RequestMapping("/ersplist_zx")
    @ResponseBody
    public Map ersplist(Ersp ersp) {
        int flag = 0;
        List<Ersp> list = erspService.selectlnew();
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("list", list);
        return map;
    }

    // 销量top
    @RequestMapping("/ersplist_top")
    @ResponseBody
    public Map ersplist_top(Ersp ersp) {
        int flag = 0;
        List<Ersp> list = erspService.selecttop();
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("list", list);
        return map;
    }


    // 全部商品
    @RequestMapping("/ersplist_all")
    @ResponseBody
    public Map ersplist_all(Ersp ersp) {
        Map<String, Object> map = new HashMap<String, Object>();
        int flag = 0;
        if(!"".equals(ersp.getRy10()) && ersp.getRy10() !=null){
            List<Ersp> list = erspService.selectlBysearch(ersp.getRy10());
            map.put("list", list);
        }else{
            if ("全部".equals(ersp.getLx())){
                ersp.setLx("");
            }

            if(!"".equals(ersp.getLx())&&ersp.getLx() !=null ){
                List<Ersp> list = erspService.selectsplist(ersp.getLx());
                map.put("list", list);
            }else{
                List<Ersp> list = erspService.selectsplist("");
                map.put("list", list);
            }
        }
        return map;
    }


    // 商品详情
    @RequestMapping("/erspdetails")
    @ResponseBody
    public Map erspdetails(Ersp ersp) {
        int flag = 0;
        Ersp bean = erspService.selectByPrimaryKey(ersp.getId());
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("list", bean);
        return map;
    }


    // 购物车
    @RequestMapping("/pcgwc")
    @ResponseBody
    public Map pcgwc(Ergwc ergwc) {
        int flag = 0;
        List<Ergwc> list = ergwcService.selectlBysearch1(ergwc.getYhid());
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("list", list);
        return map;
    }


    // 我的订单
    @RequestMapping("/myorderlist")
    @ResponseBody
    public Map myorderlist(Ergm ergm) {
        int flag = 0;
        List<Ergm> list = ergmService.selectlBysearch1(ergm.getYhid());
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("list", list);
        return map;
    }


    // 查询评价
    @RequestMapping("/pcpjlist")
    @ResponseBody
    public Map pcpjlist(Erpj erpj) {
        int flag = 0;
        List<Erpj> list = erpjService.selectlBysearch1(erpj.getSpid());
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("list", list);
        return map;
    }



    //首页
    @RequestMapping(value = "/pcindex", method = RequestMethod.GET)
    public String pcindex(ModelMap modelMap,
                          @RequestParam(value = "types", required = false) String types) {
        List<Ersp> datanew = erspService.selectlnew();
        List<Ersp> datafz = erspService.selecttop();
        List<Ersp> datawj = erspService.selecttop();
        List<Ersp> datayq = erspService.selecttop();
        modelMap.addAttribute("datanew", datanew);
        modelMap.addAttribute("datafz", datafz);
        modelMap.addAttribute("datawj", datawj);
        modelMap.addAttribute("datayq", datayq);
        return "pchtml/index1";
    }



    //商品列表
    @RequestMapping(value = "/pcsplist", method = RequestMethod.GET)
    public String pcsplist(ModelMap modelMap,
                          @RequestParam(value = "types", required = false) String types) {

        List<Ersp> erspdatas = erspService.selectsplist(types);
        modelMap.addAttribute("erspdatas", erspdatas);
        if(!"".equals(types)&&types !=null){
            modelMap.addAttribute("types",types);
        }else{
            modelMap.addAttribute("types","全部商品");
        }

        return "pchtml/list";
    }

    //搜索
    @RequestMapping(value = "/pcsearch", method = RequestMethod.GET)
    public String pcsearch(ModelMap modelMap,
                           @RequestParam(value = "sear", required = false) String sear) {
        List<Ersp> erspdatas = erspService.selectlBysearch(sear);
        modelMap.addAttribute("erspdatas", erspdatas);
        modelMap.addAttribute("types","搜索结果");
        return "pchtml/list";
    }
    //商品详情
    @RequestMapping(value = "/pcdetails+{id}")
    public String pcdetails(@PathVariable("id") String id, ModelMap modelMap) {
        Ersp erspdatas = erspService.selectByPrimaryKey(id);
        modelMap.addAttribute("erspdatas", erspdatas);

        List<Erpj> pjdatas = erpjService.selectlBysearch1(id);
        modelMap.addAttribute("pjdatas", pjdatas);

        List<Ersp> lsspdatas = erspService.selectsplist(erspdatas.getLx());
        modelMap.addAttribute("lsspdatas", lsspdatas);
        return "pchtml/details";
    }


    //注册
    @RequestMapping(value = "/pcreg", method = RequestMethod.GET)
    public String pcreg(ModelMap modelMap) {
        return "pchtml/reg";
    }

    //登录
    @RequestMapping(value = "/pclogin", method = RequestMethod.GET)
    public String pclogin(ModelMap modelMap) {
        return "pchtml/login";
    }
    //我的订单
    @RequestMapping(value = "/pcmyorder", method = RequestMethod.GET)
    public String pcmyorder(ModelMap modelMap) {
        return "pchtml/myorder";
    }

    //订单
    @RequestMapping(value = "/pcorder", method = RequestMethod.GET)
    public String pcorder(ModelMap modelMap,
                          @RequestParam(value = "yhid", required = false) String yhid) {
        List<Ergm> bean = ergmService.selectlBysearch1(yhid);
        modelMap.addAttribute("datasgmb", bean);
        return "pchtml/myorder";
    }

//    //我的购物车
//    @RequestMapping(value = "/pcgwc", method = RequestMethod.GET)
//    public String pcgwc(ModelMap modelMap,
//                        @RequestParam(value = "yhid", required = false) String yhid) {
//        List<Ergwc> bean = ergwcService.selectlBysearch1(yhid);
//        modelMap.addAttribute("datasgwc", bean);
//        return "pchtml/gwc";
//    }

    //删除购物车
    @RequestMapping("/gwcdel")
    @ResponseBody
    public Map gwcdel(Ergwc gwc) {
        Map<String, Object> map = new HashMap<String, Object>();
        int flag = ergwcService.deleteByPrimaryKey(gwc.getId());
        if (flag == 1) {
            map.put("code", "success");
            return map;
        } else {
            map.put("code", "error");
            return map;
        }


    }

    //购买
    @RequestMapping(value = "/pcgm", method = RequestMethod.GET)
    public String pcgm(ModelMap modelMap) {
        return "pchtml/gm";
    }

    //购买
    @RequestMapping(value = "/pcgm1", method = RequestMethod.GET)
    public String pcgm1(ModelMap modelMap) {
        return "pchtml/gm1";
    }




}
