package com.example.test.controller;


import com.example.test.bean.Erts;
import com.example.test.service.ErtsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.text.SimpleDateFormat;
import java.util.*;

@Controller
public class ErtsController {


    @Autowired
    ErtsService ertsService;



    /**
     * 新增
     */
    @RequestMapping("/adderts")
    @ResponseBody
    public Map adderts(Erts erts) {
        Date date = new Date();
        erts.setId(UUID.randomUUID().toString().trim().replaceAll("-", ""));
        String nowtime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()).toString();
        erts.setSj(nowtime);
        int flag = ertsService.insert(erts);
        Map<String, Object> map = new HashMap<String, Object>();
        if (flag == 1) {
            map.put("code", "success");
            return map;
        } else {
            map.put("code", "error");
            return map;
        }
    }


    /**
     * 修改
     */
    @RequestMapping("/updateerts")
    @ResponseBody
    public Map updateerts(Erts erts) {
        int flag = ertsService.updateByPrimaryKey(erts);
        Map<String, Object> map = new HashMap<String, Object>();
        if (flag == 1) {
            map.put("code", "success");
            return map;
        } else {
            map.put("code", "error");
            return map;
        }
    }

    //删除
    @RequestMapping("/deleteerts")
    @ResponseBody
    public Map deleteerts(Erts erts) {
        int flag = ertsService.deleteByPrimaryKey(erts.getId());
        Map<String, Object> map = new HashMap<String, Object>();
        if (flag > 0) {
            map.put("code", "success");
        } else {
            map.put("code", "error");
        }
        return map;
    }

    // 清单
    @RequestMapping("/ertslist")
    @ResponseBody
    public Map ertslist(Erts erts) {
        int flag = 0;
        List<Erts> list = ertsService.selectlBysearch(erts.getNr());
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("list", list);
        return map;
    }

}
