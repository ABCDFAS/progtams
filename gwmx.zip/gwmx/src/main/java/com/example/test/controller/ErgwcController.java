package com.example.test.controller;



import com.example.test.bean.Ergwc;
import com.example.test.service.ErgwcService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.text.SimpleDateFormat;
import java.util.*;

@Controller
public class ErgwcController {


    @Autowired
    ErgwcService ergwcService;


    //列表弹窗
    @RequestMapping(value = "/ergwclist", method = RequestMethod.GET)
    public String ergwclist(ModelMap modelMap,
                          @RequestParam(value = "sear", required = false) String sear) {
        List<Ergwc> list = ergwcService.selectlBysearch(sear);
        modelMap.addAttribute("datas", list);
        return "html/ergwclist";
    }

    //新增弹窗
    @RequestMapping("/ergwcadd")
    public String ergwcaddshow(ModelMap modelMap) {
        List<Ergwc> list = ergwcService.selectlBysearch("");
        modelMap.addAttribute("datas", list);
        return "html/ergwcadd";
    }


    //数据新增
    @RequestMapping("/addergwc")
    @ResponseBody
    public Map addergwc(Ergwc ergwc) {
        Date date = new Date();
        ergwc.setId(UUID.randomUUID().toString().trim().replaceAll("-", ""));

        String nowtime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()).toString();
        ergwc.setSj(nowtime);
        int flag = ergwcService.insert(ergwc);
        Map<String, Object> map = new HashMap<String, Object>();
        if (flag == 1) {
            map.put("code", "success");
            return map;
        } else {
            map.put("code", "error");
            return map;
        }
    }

    /**
     * 删除
     */
    @RequestMapping(value = "/deleteergwc+{id}")
    public String deleteergwc(@PathVariable("id") String id, ModelMap modelMap) {
        int flag = ergwcService.deleteByPrimaryKey(id);
        List<Ergwc> list = ergwcService.selectlBysearch("");
        modelMap.addAttribute("datas", list);
        return "html/ergwclist";
    }

    //修改弹窗
    @RequestMapping(value = "ergwcedit", method = RequestMethod.GET)
    public String ergwcedit(
            @RequestParam(name = "id", required = true) String id, ModelMap modelMap) {
        Ergwc bean = ergwcService.selectByPrimaryKey(id);
        modelMap.addAttribute("datas", bean);

        List<Ergwc> list = ergwcService.selectlBysearch("");
        modelMap.addAttribute("datasrole", list);
        return "html/ergwcedit";
    }

     //修改
    @RequestMapping("/updateergwc")
    @ResponseBody
    public Map updateergwc(Ergwc ergwc) {
        int flag = ergwcService.updateByPrimaryKey(ergwc);
        Map<String, Object> map = new HashMap<String, Object>();
        if (flag == 1) {
            map.put("code", "success");
            return map;
        } else {
            map.put("code", "error");
            return map;
        }
    }

}
