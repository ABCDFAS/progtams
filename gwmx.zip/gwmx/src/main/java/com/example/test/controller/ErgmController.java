package com.example.test.controller;



import com.example.test.bean.Ergm;
import com.example.test.bean.Ergm;
import com.example.test.bean.Ersp;
import com.example.test.service.ErgmService;
import com.example.test.service.ErspService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.text.SimpleDateFormat;
import java.util.*;

@Controller
public class ErgmController {


    @Autowired
    ErgmService ergmService;


    @Autowired
    ErspService erspService;


    /**
     * 新增
     */
    @RequestMapping("/addergm")
    @ResponseBody
    public Map addergm(Ergm ergm) {
        Map<String, Object> map = new HashMap<String, Object>();
        //判断库存是不是足够
        Ersp ersp = erspService.selectByPrimaryKey(ergm.getSpid());
        int kc = Integer.parseInt(ersp.getPl());
        if (kc==0){
            map.put("code", "nkc");
            return map;
        }else{

            Date date = new Date();
            ergm.setId(UUID.randomUUID().toString().trim().replaceAll("-", ""));
            String nowtime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()).toString();
            ergm.setSj(nowtime);
            int flag = ergmService.insert(ergm);
            //库存减少
            int yl = kc-1;
            ersp.setPl(String.valueOf(yl));
            erspService.updateByPrimaryKey(ersp);
            if (flag == 1) {
                map.put("code", "success");
                return map;
            } else {
                map.put("code", "error");
                return map;
            }

        }

    }


    /**
     * 修改
     */
    @RequestMapping("/updateergm")
    @ResponseBody
    public Map updateergm(Ergm ergm) {
        int flag = ergmService.updateByPrimaryKey(ergm);
        Map<String, Object> map = new HashMap<String, Object>();
        if (flag == 1) {
            map.put("code", "success");
            return map;
        } else {
            map.put("code", "error");
            return map;
        }
    }

    //删除
    @RequestMapping("/deleteergm")
    @ResponseBody
    public Map deleteergm(Ergm ergm) {
        int flag = ergmService.deleteByPrimaryKey(ergm.getId());
        Map<String, Object> map = new HashMap<String, Object>();
        if (flag > 0) {
            map.put("code", "success");
        } else {
            map.put("code", "error");
        }
        return map;
    }

    // 清单
    @RequestMapping("/ergmlist")
    @ResponseBody
    public Map ergmlist(Ergm ergm) {
        int flag = 0;
        List<Ergm> list = ergmService.selectlBysearch(ergm.getSpmc());
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("list", list);
        return map;
    }

    // 清单
    @RequestMapping("/ergm_yhlist")
    @ResponseBody
    public Map ergm_yhlist(Ergm ergm) {
        int flag = 0;
        List<Ergm> list = ergmService.selectlBysearch22(ergm.getRy5(),ergm.getSpmc());
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("list", list);
        return map;
    }

    //走势图(按日期统计)
    @RequestMapping("/tjt1data")
    @ResponseBody
    public Map tjt1data(Ergm ergm) {
        Map<String, Object> map = new HashMap<String, Object>();
        List<Ergm> list = ergmService.selectlBysearch2();
        String[] arrx = new String[list.size()];
        String[] arry= new String[list.size()];
        for (int i = 0; i < list.size(); i++) {
            arrx[i] = list.get(i).getYhid();
        }
        for (int i = 0; i < list.size(); i++) {
            arry[i] = list.get(i).getId();
        }
        map.put("arrx", arrx);
        map.put("arry", arry);
        return map;
    }

    //走势图(按状态统计)
    @RequestMapping("/tjt2data")
    @ResponseBody
    public Map tjt2data(Ergm ergm) {
        Map<String, Object> map = new HashMap<String, Object>();
        List<Ergm> list = ergmService.selectlBysearch3();
        String[] arrx = new String[list.size()];
        String[] arry= new String[list.size()];
        for (int i = 0; i < list.size(); i++) {
            arrx[i] = list.get(i).getYhid();
        }
        for (int i = 0; i < list.size(); i++) {
            arry[i] = list.get(i).getId();
        }
        map.put("arrx", arrx);
        map.put("arry", arry);
        return map;
    }

    //走势图(按商品统计)
    @RequestMapping("/tjt3data")
    @ResponseBody
    public Map tjt3data(Ergm ergm) {
        Map<String, Object> map = new HashMap<String, Object>();
        List<Ergm> list = ergmService.selectlBysearch4();
        String[] arrx = new String[list.size()];
        String[] arry= new String[list.size()];
        for (int i = 0; i < list.size(); i++) {
            arrx[i] = list.get(i).getYhid();
        }
        for (int i = 0; i < list.size(); i++) {
            arry[i] = list.get(i).getId();
        }
        map.put("arrx", arrx);
        map.put("arry", arry);
        return map;
    }
}
