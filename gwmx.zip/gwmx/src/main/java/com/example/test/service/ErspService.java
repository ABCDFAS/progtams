package com.example.test.service;

import com.example.test.bean.Ersp;

import java.util.List;

public interface ErspService {


    List<Ersp> selectlBysearch(String sear);

    List<Ersp> selectlBysearch1(String ry10,String mc);

    List<Ersp> selectlnew();

    List<Ersp> selecttop( );

    List<Ersp> selectsplist(String lx);


    int insert(Ersp record);

    int deleteByPrimaryKey(String id);

    Ersp selectByPrimaryKey(String id);

    int updateByPrimaryKey(Ersp record);

}
