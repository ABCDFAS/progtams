package com.example.test.serviceImpl;

import com.example.test.bean.Erts;
import com.example.test.mapper.ErtsMapper;
import com.example.test.service.ErtsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ErtsServiceImpl implements ErtsService {

    @Autowired
    ErtsMapper ertsMapper;

    @Override
    public List<Erts> selectlBysearch(String sear) {
        return ertsMapper.selectlBysearch(sear);
    }

    @Override
    public int insert(Erts record) {
        int aFlag = ertsMapper.insert(record);
        return aFlag;
    }

    @Override
    public int deleteByPrimaryKey(String id) {
        int aFlag = ertsMapper.deleteByPrimaryKey(id);
        return aFlag;
    }

    @Override
    public Erts selectByPrimaryKey(String id) {
        return ertsMapper.selectByPrimaryKey(id);
    }

    @Override
    public int updateByPrimaryKey(Erts record) {
        int aFlag = ertsMapper.updateByPrimaryKeySelective(record);
        return aFlag;
    }


}