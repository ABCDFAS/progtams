package com.example.test.serviceImpl;

import com.example.test.bean.Erpj;
import com.example.test.mapper.ErpjMapper;
import com.example.test.service.ErpjService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ErpjServiceImpl implements ErpjService {

    @Autowired
    ErpjMapper erpjMapper;

    @Override
    public List<Erpj> selectlBysearch(String sear) {
        return erpjMapper.selectlBysearch(sear);
    }

    @Override
    public List<Erpj> selectlBysearch1(String spid) {
        return erpjMapper.selectlBysearch1(spid);
    }


    @Override
    public int insert(Erpj record) {
        int aFlag = erpjMapper.insert(record);
        return aFlag;
    }

    @Override
    public int deleteByPrimaryKey(String id) {
        int aFlag = erpjMapper.deleteByPrimaryKey(id);
        return aFlag;
    }

    @Override
    public Erpj selectByPrimaryKey(String id) {
        return erpjMapper.selectByPrimaryKey(id);
    }

    @Override
    public int updateByPrimaryKey(Erpj record) {
        int aFlag = erpjMapper.updateByPrimaryKeySelective(record);
        return aFlag;
    }


}