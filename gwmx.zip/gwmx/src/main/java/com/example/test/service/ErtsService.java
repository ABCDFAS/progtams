package com.example.test.service;

import com.example.test.bean.Erts;

import java.util.List;

public interface ErtsService {


    List<Erts> selectlBysearch(String sear);



    int insert(Erts record);

    int deleteByPrimaryKey(String id);

    Erts selectByPrimaryKey(String id);

    int updateByPrimaryKey(Erts record);

}
