package com.example.test.serviceImpl;

import com.example.test.bean.Ersp;
import com.example.test.mapper.ErspMapper;
import com.example.test.service.ErspService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ErspServiceImpl implements ErspService {

    @Autowired
    ErspMapper erspMapper;

    @Override
    public List<Ersp> selectlBysearch(String sear) {
        return erspMapper.selectlBysearch(sear);
    }

    @Override
    public List<Ersp> selectlBysearch1(String ry10,String mc) {
        return erspMapper.selectlBysearch1( ry10, mc);
    }

    @Override
    public List<Ersp> selectlnew( ) {
        return erspMapper.selectlnew();
    }

    @Override
    public List<Ersp> selecttop( ) {
        return erspMapper.selecttop();
    }

    @Override
    public List<Ersp> selectsplist(String lx) {
        return erspMapper.selectsplist(lx);
    }

    @Override
    public int insert(Ersp record) {
        int aFlag = erspMapper.insert(record);
        return aFlag;
    }

    @Override
    public int deleteByPrimaryKey(String id) {
        int aFlag = erspMapper.deleteByPrimaryKey(id);
        return aFlag;
    }

    @Override
    public Ersp selectByPrimaryKey(String id) {
        return erspMapper.selectByPrimaryKey(id);
    }

    @Override
    public int updateByPrimaryKey(Ersp record) {
        int aFlag = erspMapper.updateByPrimaryKeySelective(record);
        return aFlag;
    }


}