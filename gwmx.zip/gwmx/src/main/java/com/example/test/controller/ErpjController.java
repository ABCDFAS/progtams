package com.example.test.controller;



import com.example.test.bean.Erpj;
import com.example.test.service.ErpjService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.text.SimpleDateFormat;
import java.util.*;

@Controller
public class ErpjController {


    @Autowired
    ErpjService erpjService;


    //列表弹窗
    @RequestMapping(value = "/erpjlist", method = RequestMethod.GET)
    public String erpjlist(ModelMap modelMap,
                          @RequestParam(value = "sear", required = false) String sear) {
        List<Erpj> list = erpjService.selectlBysearch(sear);
        modelMap.addAttribute("datas", list);
        return "html/erpjlist";
    }

    //新增弹窗
    @RequestMapping("/erpjadd")
    public String erpjaddshow(ModelMap modelMap) {
        List<Erpj> list = erpjService.selectlBysearch("");
        modelMap.addAttribute("datas", list);
        return "html/erpjadd";
    }


    //数据新增
    @RequestMapping("/adderpj")
    @ResponseBody
    public Map adderpj(Erpj erpj) {
        Date date = new Date();
        erpj.setId(UUID.randomUUID().toString().trim().replaceAll("-", ""));

        String nowtime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()).toString();
        erpj.setSj(nowtime);
        int flag = erpjService.insert(erpj);
        Map<String, Object> map = new HashMap<String, Object>();
        if (flag == 1) {
            map.put("code", "success");
            return map;
        } else {
            map.put("code", "error");
            return map;
        }
    }

    /**
     * 删除
     */
    @RequestMapping(value = "/deleteerpj+{id}")
    public String deleteerpj(@PathVariable("id") String id, ModelMap modelMap) {
        int flag = erpjService.deleteByPrimaryKey(id);
        List<Erpj> list = erpjService.selectlBysearch("");
        modelMap.addAttribute("datas", list);
        return "html/erpjlist";
    }

    //修改弹窗
    @RequestMapping(value = "erpjedit", method = RequestMethod.GET)
    public String erpjedit(
            @RequestParam(name = "id", required = true) String id, ModelMap modelMap) {
        Erpj bean = erpjService.selectByPrimaryKey(id);
        modelMap.addAttribute("datas", bean);

        List<Erpj> list = erpjService.selectlBysearch("");
        modelMap.addAttribute("datasrole", list);
        return "html/erpjedit";
    }

     //修改
    @RequestMapping("/updateerpj")
    @ResponseBody
    public Map updateerpj(Erpj erpj) {
        int flag = erpjService.updateByPrimaryKey(erpj);
        Map<String, Object> map = new HashMap<String, Object>();
        if (flag == 1) {
            map.put("code", "success");
            return map;
        } else {
            map.put("code", "error");
            return map;
        }
    }

}
